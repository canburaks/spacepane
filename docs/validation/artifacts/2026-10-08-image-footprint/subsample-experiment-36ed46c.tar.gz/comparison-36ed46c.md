# Q154 ignored experiment result at 36ed46c

Build and separate policy/fallback checks passed without source repairs. Both full reports passed the strict scenario, metric, bitmap, cancellation and experiment-counter validators. No tracked file changed. The subsample hint provides no meaningful memory reduction in these fixtures, and the 100 MiB starting incremental target remains unmet.

## Paired identity and sample inventory

- Revision: `36ed46cb4297afe44a7665e673ff33e1272c26d4`; both source states clean.
- Source tree SHA-256: `aa4776e766de24726847c951a94788400c1d6bfa41c2ac047f8465bc93001493`.
- Same executable SHA-256: `6a829d2f42b51b3b65b7605d6d8bb35ebb48af7fc51ffa4fdcf111ba3f612575`.
- Same build context SHA-256: `e1bd7ed86fd7e2962700ec55677ac8c38313c5fdc230cc721e4e562d863dc8d8`.
- Identical environment, fixture manifests/SHA-256s, scenario inventory, encoded bytes, source dimensions, requested sides, output dimensions, component depth, row stride and storage bytes. The mode label is the sole configuration difference.
- Each mode: seven scenarios, three fresh cold processes per scenario, and a fresh warm process per scenario with one explicit unmeasured warmup plus five measured samples: 56 measured samples. Production has 2,966 physical probes; candidate has 2,580. All samples report thermal state 0.
- Candidate measured calls: 32 hinted, 56 unhinted, zero fallbacks. This counts requests for factor 2 and does not observe effective internal subsampling. All 100 MP requests are refused before native work. AVIF and 16 MP requests bypass the hint.
- All eight retired tasks per mode return no bitmap after causal admission cancellation; native-C cancellation remains unobservable.

## Maximum sampled increase above each sample baseline (MiB)

| Scenario | Production cold | Candidate cold | Production warm | Candidate warm |
| --- | ---: | ---: | ---: | ---: |
| png40-rgba | 115.063 | 115.047 | 101.156 | 101.156 |
| jpeg40-rgb | 116.422 | 115.438 | 107.078 | 107.078 |
| png16-pair | 249.407 | 249.485 | 245.110 | 245.078 |
| png40-plus16-pair | 263.422 | 263.204 | 245.031 | 247.610 |
| refused100-rgba | 4.469 | 4.469 | 0.094 | 0.109 |
| tiny-avif | 5.250 | 5.282 | 0.141 | 0.406 |
| cancel-replace | 265.063 | 264.922 | 246.922 | 246.078 |

The mixed and cancellation distributions vary strongly with observed admission concurrency: every low mixed/cancellation sample reports a maximum of one active lease, while the high samples report two. Different concurrent arrival order through the FIFO gate is a plausible explanation; exact arrival order was not recorded. Cold mixed increases span 140.532–263.422 MiB in production and 140.625–263.204 MiB in the candidate. Warm mixed spans 122.422–245.031 MiB and 122.469–247.610 MiB respectively. These differences cannot establish hint effectiveness. The single PNG and concurrent 16 MP maxima are effectively unchanged.

## Absolute sampled peak / kernel lifetime peak (MiB)

Kernel lifetime peaks are independent process totals. Warm peaks include earlier warmup and samples; they are not individual-request increments. Values below show maximum sampled physical footprint followed by maximum kernel lifetime peak.

| Scenario | Production cold | Candidate cold | Production warm | Candidate warm |
| --- | ---: | ---: | ---: | ---: |
| png40-rgba | 117.282 / 117.282 | 117.266 / 117.266 | 119.610 / 119.610 | 119.516 / 119.516 |
| jpeg40-rgb | 118.673 / 120.751 | 117.657 / 121.782 | 119.876 / 120.048 | 119.532 / 123.735 |
| png16-pair | 251.657 / 251.657 | 251.720 / 251.720 | 252.907 / 252.907 | 252.829 / 252.829 |
| png40-plus16-pair | 265.641 / 265.641 | 265.438 / 265.438 | 267.454 / 267.454 | 269.173 / 269.173 |
| refused100-rgba | 6.688 / 6.719 | 6.688 / 6.688 | 7.079 / 7.079 | 7.126 / 7.126 |
| tiny-avif | 7.501 / 7.501 | 7.501 / 7.501 | 6.329 / 6.329 | 6.735 / 6.735 |
| cancel-replace | 267.282 / 267.282 | 267.142 / 267.142 | 271.595 / 271.595 | 269.423 / 269.423 |

The JPEG candidate has a lower sampled cold maximum by less than 1 MiB but a higher cold kernel peak (121.782 vs 120.751 MiB) and higher warm kernel peak (123.735 vs 120.048 MiB). This is insufficient evidence of improvement.

## Explicit held references / immediate post-drop maxima (MiB)

The phases hold only decoded CGImage references. No AppKit draw or view cache was exercised. A dropped Swift reference does not establish allocator or framework memory release. Each cell shows maximum held-reference footprint followed by immediate post-drop footprint across all eight samples.

| Scenario | Production | Candidate |
| --- | ---: | ---: |
| png40-rgba | 20.391 / 20.329 | 20.298 / 20.235 |
| jpeg40-rgb | 14.641 / 14.595 | 14.563 / 14.501 |
| png16-pair | 8.579 / 8.470 | 8.517 / 8.423 |
| png40-plus16-pair | 23.220 / 23.064 | 24.845 / 24.673 |
| refused100-rgba | 7.079 / 7.079 | 7.126 / 7.126 |
| tiny-avif | 7.501 / 7.485 | 7.501 / 7.485 |
| cancel-replace | 27.283 / 27.111 | 25.095 / 24.923 |

## Preserved evidence and next question

- Raw results/logs: `production-36ed46c.{json,log}`, `safe-subsample-2-36ed46c.{json,log}`.
- Build/policy logs: `subsample-36ed46c-build.log`, `subsample-36ed46c-policy.log`.
- Derived distributions: `comparison-36ed46c.json`.
- Accepted 293fcb2 original evidence remains untouched.

No production change is justified by this hint-only result. A separately authorized serialized 8 MP experiment should isolate admission effects before any 4 MP detail reduction. Single 40 MP decoding still exceeds 100 MiB, so serialized admission cannot be assumed to close that target. Actual AppKit drawing and held-cache measurement remain separate requirements before considering the 192 MiB resident budget.

The candidate adds metadata reads, counters and output validation relative to the production native implementation; this measures end-to-end experimental behavior rather than the isolated key cost. The unexercised fallback path still retains a rejected hinted image while retrying and needs a narrow lifetime review before any shipping proposal. These decoder-only synthetic-fixture results are standalone-process evidence on macOS 27.2 with a macOS 15 deployment target; they do not prove Finder, actual held cache/drawing, minimum-OS runtime, shared system/child process totals, or combined CAD behavior.

Compiler/measurement slot released after the paired runs. Tracked status verified clean.
