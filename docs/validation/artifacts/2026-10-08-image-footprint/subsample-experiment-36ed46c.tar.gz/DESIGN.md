# Q-154 subsample investigation (ignored; not shipping code)

Accepted evidence stays untouched: `../release-images-293fcb2.json`, generated at clean `293fcb2baa3a1b7dbc07ad5d467ec64e84eb8499`. Its 56 samples establish a standalone decoder workload exceeding the 100 MiB starting incremental target. They do not close the target, cache/drawing, Finder, combined CAD, or macOS 15 gates.

The measured maxima above baseline were 115.313 MiB for cold 40 MP PNG, 118.485 MiB for cold 40 MP JPEG, 249.500 MiB for two 16 MP PNGs, 263.282 MiB for 40 MP plus two 16 MP PNGs, and 264.985 MiB for cancellation/replacement. Single-image evidence means serial admission alone cannot be assumed sufficient. `NativeImagePagesView` independently permits 192 MiB of logical resident bitmap storage.

## First experiment: preserve output resolution

`benchmark_release_image_subsample.py` builds one Release `-O -enable-testing` executable, whose two modes share the production `ImagePageDecoder` metadata/cancellation/admission path and all current 8 MP request sizes. The `production` control calls the unmodified native decoder. `safe-subsample-2` injects an experimental native ImageIO closure through the existing `NativeDecode` seam. No production sources change.

Apple documents `kCGImageSourceSubsampleFactor` for JPEG, HEIF, TIFF and PNG with integer factors 2, 4 or 8; the current SDK header declares macOS 10.11 availability. The experiment selects only factor 2, only for the already-admitted JPEG/PNG/HEIC types, and only if the source's half-sized longest dimension still covers the requested result. It does not add TIFF support or apply the hint to AVIF/GIF/WebP. The 40 MP fixture satisfies this condition; the 16 MP fixture at 2829 px does not.

The hint may be ignored or produce a larger/full normal image. Every returned image must preserve the original aspect ratio and requested longest side (one-pixel rounding allowance), remain at or below the requested/source dimensions, and have non-overflowing row-stride storage. An invalid hinted result triggers one retry without the hint, inside the same production admission lease. An invalid fallback is refused. Counters report requested native hint/bypass/fallback calls; they cannot prove which subsampling factor ImageIO actually used internally.

`ReleaseImageDecodeExperiment --check-experiment-policy` is a separate unmeasured process: unsupported-family and insufficient-ratio bypass; valid factor selection; source-cap rejection; nil, oversized and wrong-aspect hinted results falling back to a valid bitmap; valid results avoiding fallback; oversized fallback refused. This command is prepared but has not been compiled or run.

The runner fingerprints production inputs using the existing source-state helper, plus both ignored Swift sources and the ignored Python runner. It verifies source, build, executable and fixture identities before/after each measured process. Both modes use the same executable/build context. Compare only runs with identical fixture SHA-256s, requests, source state, executable hash and build-context hash; retain the separate native mode label. Use three fresh cold processes and a fresh warm process with one unmeasured warmup plus five measured samples for every required scenario. Do not compare a new drawn stage against the old decoder-only measurements.

After the lead grants a frozen exclusive compiler slot:

1. Run the runner in `production` mode with `--build-only`.
2. Run the worker's policy-check command in its own unmeasured process.
3. Run `production` and `safe-subsample-2` modes with `--skip-build` into distinct raw files. Prefer a second reversed-order pair if the apparent effect is small or inconsistent.
4. Validate both reports and compare complete per-phase distributions, sample and separate kernel lifetime maxima, bitmap geometry/storage, trace counts and all fingerprints. A lower maximum from a few samples is experimental evidence, not release-wide acceptance.

## Subsequent candidates if needed

A separate 4 MP request-area candidate allows factor 2 for the 16 MP square: 2000 px instead of 2829 px. Pair this with a separately evaluated one-native-call production policy if needed; do not conflate its effect with the first hint-only experiment. Retain the 40 MP source cap and 100 MiB target. This reduces output detail and requires view-quality and regression evidence rather than a silent threshold adjustment.

Resident caching requires a separate proposed bound and actual view-level measurement. The current 192 MiB logical cache limit can exceed the physical starting target before native scratch work is included. A smaller cache must still keep visible pages and accessible fallback states coherent, and its policy must not count a released reference as proof of allocator release.

## Separate drawn/held-page stage

The existing report holds CGImage references after immediate ImageIO decoding but does not invoke `ImagePageFrameView.draw`. Logical bitmap storage of 32–96 MiB accompanied by much smaller physical held readings cannot establish materialized/cached preview memory.

A separate baseline/candidate harness stage must mount actual `ImagePageFrameView` or `NativeImagePagesView` pages, render through the existing AppKit draw path to a bounded bitmap, hold the page images/drawing destination while probing, and then clear/drop each owner explicitly. Use actual `ImagePageScheduler`/`NativeImagePagesView` delivery and resident-byte accounting for cache claims. Record destination row stride/height and bytes separately; the offscreen destination adds real memory that must be labeled. Use a bounded fixed viewport/backing scale and retain the decoded source arrays only while the stage owns them. Sample decode, first draw, held cache and clear phases with fresh drained samplers.

Offscreen AppKit drawing is additional standalone-process evidence. It does not measure Finder first paint, WindowServer/GPU/shared service totals or CAD helper memory. Cold kernel lifetime growth and per-stage sampled maxima remain separate; warm process lifetime peaks cannot be assigned to a single request.

Sources: [Apple subsample documentation](https://developer.apple.com/documentation/imageio/kcgimagesourcesubsamplefactor), [immediate caching](https://developer.apple.com/documentation/imageio/kcgimagesourceshouldcacheimmediately), [thumbnail maximum](https://developer.apple.com/documentation/imageio/kcgimagesourcethumbnailmaxpixelsize). SDK declarations inspected read-only at `ImageIO.framework/Headers/CGImageSource.h`.
