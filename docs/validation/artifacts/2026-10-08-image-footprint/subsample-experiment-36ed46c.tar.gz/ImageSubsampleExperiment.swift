import CoreGraphics
import Foundation
import ImageIO
import Synchronization
import PreviewContracts
@testable import PreviewRenderers

enum ImageDecodeExperimentMode: String, Sendable {
    case production
    case safeSubsample2 = "safe-subsample-2"
}

struct ImageDecodeExperimentCounts: Codable, Sendable {
    var hintedCalls = 0
    var unhintedCalls = 0
    var fallbackCalls = 0
}

/// Experimental native implementation only. The production decoder still performs header validation,
/// owns admission/cancellation, and refuses sources over 40 MP before this closure can run.
final class ImageDecodeExperiment: Sendable {
    let mode: ImageDecodeExperimentMode
    private let state = Mutex(ImageDecodeExperimentCounts())
    init(mode: ImageDecodeExperimentMode) { self.mode = mode }
    var counts: ImageDecodeExperimentCounts { state.withLock { $0 } }

    @concurrent
    func decode(_ data: Data, maximumPixelSize: Int, admission: ImageDecodeAdmission) async -> DecodedPageImage? {
        if mode == .production {
            return await ImagePageDecoder.decode(data, maximumPixelSize: maximumPixelSize, admission: admission)
        }
        return await ImagePageDecoder.decode(data, maximumPixelSize: maximumPixelSize, admission: admission,
                                            nativeDecode: { [self] data, size in await thumbnail(data, size) })
    }

    /// Pick only 2x in this first experiment, and only when it preserves the requested resolution.
    /// The key is a hint: ImageIO may ignore an unsupported factor; no effective-factor claim is made.
    static func hint(format: PreviewImageFormat, width: Int, height: Int, requested: Int) -> Int? {
        guard [.jpeg, .png, .heic].contains(format), requested > 0,
              PreviewImageLimits.sourcePixelCount(width: width, height: height) != nil,
              max(width, height) / 2 >= requested else { return nil }
        return 2
    }

    static func accepts(_ image: CGImage?, width: Int, height: Int, requested: Int) -> Bool {
        guard let image, width > 0, height > 0 else { return false }
        let side = min(requested, max(width, height))
        guard side > 0, image.width > 0, image.height > 0,
              image.width <= min(width, side), image.height <= min(height, side),
              max(image.width, image.height) >= side - 1,
              abs(image.width * height - image.height * width) <= max(width, height) else { return false }
        let storage = image.bytesPerRow.multipliedReportingOverflow(by: image.height)
        return image.bytesPerRow > 0 && !storage.overflow && storage.partialValue > 0
    }

    /// An ignored/unsupported hint must not silently weaken dimensions or return a full-sized image.
    /// Retry once with the unchanged production options, inside the same native admission lease.
    static func resolve(_ hinted: CGImage?, width: Int, height: Int, requested: Int,
                        fallback: () -> CGImage?) -> CGImage? {
        if accepts(hinted, width: width, height: height, requested: requested) { return hinted }
        let image = fallback()
        return accepts(image, width: width, height: height, requested: requested) ? image : nil
    }

    @concurrent private func thumbnail(_ data: Data, _ requested: Int) async -> DecodedPageImage? {
        guard !Task.isCancelled, let format = PreviewImageFormat.sniff(data) else { return nil }
        let sourceOptions = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let source = CGImageSourceCreateWithData(data as CFData, sourceOptions),
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, sourceOptions) as? [CFString: Any],
              var width = (properties[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue,
              var height = (properties[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue else { return nil }
        if let orientation = (properties[kCGImagePropertyOrientation] as? NSNumber)?.intValue, (5...8).contains(orientation) {
            swap(&width, &height)
        }
        var options: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                                      kCGImageSourceCreateThumbnailWithTransform: true,
                                      kCGImageSourceThumbnailMaxPixelSize: requested,
                                      kCGImageSourceShouldCacheImmediately: true]
        let factor = Self.hint(format: format, width: width, height: height, requested: requested)
        if let factor { options[kCGImageSourceSubsampleFactor] = factor }
        guard !Task.isCancelled else { return nil }
        state.withLock { if factor != nil { $0.hintedCalls += 1 } else { $0.unhintedCalls += 1 } }
        let attempted = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
        let image: CGImage?
        if factor != nil {
            image = Self.resolve(attempted, width: width, height: height, requested: requested) { [self] in
                guard !Task.isCancelled else { return nil }
                state.withLock { $0.fallbackCalls += 1 }
                options[kCGImageSourceSubsampleFactor] = nil
                return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
            }
        } else {
            image = Self.accepts(attempted, width: width, height: height, requested: requested) ? attempted : nil
        }
        return image.map { DecodedPageImage(image: $0) }
    }

    /// Separate executable check, never included in any measured cold/warm worker process.
    static func checkPolicy() throws {
        enum Failure: Error { case policy }
        guard hint(format: .png, width: 8000, height: 5000, requested: 3578) == 2,
              hint(format: .jpeg, width: 8000, height: 5000, requested: 3578) == 2,
              hint(format: .png, width: 4000, height: 4000, requested: 2829) == nil,
              hint(format: .png, width: 10000, height: 10000, requested: 2829) == nil,
              [PreviewImageFormat.avif, .webP, .gif].allSatisfy({ hint(format: $0, width: 8000, height: 5000, requested: 3578) == nil }) else { throw Failure.policy }
        func bitmap(_ width: Int, _ height: Int) throws -> CGImage {
            guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: 0,
                                          space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue),
                  let image = context.makeImage() else { throw Failure.policy }
            return image
        }
        let valid = try bitmap(16, 12)
        let oversized = try bitmap(32, 24)
        let distorted = try bitmap(16, 16)
        var fallbacks = 0
        for invalid in [Optional<CGImage>.none, oversized, distorted] {
            let image = resolve(invalid, width: 32, height: 24, requested: 16) { fallbacks += 1; return valid }
            guard image === valid else { throw Failure.policy }
        }
        guard fallbacks == 3, resolve(valid, width: 32, height: 24, requested: 16, fallback: { fallbacks += 1; return nil }) === valid,
              fallbacks == 3, resolve(nil, width: 32, height: 24, requested: 16, fallback: { oversized }) == nil else { throw Failure.policy }
    }
}
