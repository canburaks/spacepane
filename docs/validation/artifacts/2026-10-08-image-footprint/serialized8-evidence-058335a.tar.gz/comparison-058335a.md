# Q154 serialized 8 MP experiment at 058335a

Build and separate policy check passed without repairs. All seven scenarios passed three fresh cold processes and a fresh warm process with one unmeasured warmup plus five measured samples in each mode: 56 measured samples per mode, 112 total. Both reports passed the strict scenario/metric/geometry/admission validators. All samples report thermal state 0. The compiler/measurement slot was released after the paired runs; tracked status was clean at measurement completion.

Both modes call the unchanged production native ImageIO decoder with unchanged 8 MP requests and the 40 MP source cap. The control uses processWide admission; the candidate uses one retained instance of the same production gate with capacity one. Cancellation uses a retained gate at the selected bound plus a causal acquisition observer. No production optimization or resident-budget change has been selected.

## Matched identities and outputs

- Revision: `058335a08bff228ee7870a4f1b61f002d62523ba`, clean in both reports.
- Source SHA-256: `2964708c0659546f91bae87569e363c6f35c281e122d4afdd377a3297c833905`.
- Same executable SHA-256: `318f2f12d73f80b1b1c11b3c47c39a06c7928c2f8188897cf707042455e7f021`.
- Same build context SHA-256: `c1e3806c251748cc8cb6337b53a7837d1f871584f0ebb77fa331d540e32d2778`.
- Environment and all fixture manifests/SHA-256s match. Exact encoded-byte inventories, source dimensions, requested sides, decoded dimensions/component depths/row strides/storage and refusal counts match across all measured samples. Mode selection is the sole configuration difference.
- The control observed maximum two active leases for every 16 MP pair sample. The candidate observed maximum one for every admitted heavy/mixed/cancellation sample. Both modes observed zero for the 100 MP refusal. Gates drained fully before reset.
- Production collected 2,761 physical probes; candidate collected 3,283. Every sample has at least four probes. All sixteen total cancelled retired tasks returned no bitmap; native-C cancellation remains unobservable.

## Maximum sampled increase above each sample baseline (MiB)

| Scenario | Production cold | Serialized cold | Production warm | Serialized warm |
| --- | ---: | ---: | ---: | ---: |
| png40-rgba | 115.094 | 115.203 | 101.094 | 101.078 |
| jpeg40-rgb | 116.438 | 116.391 | 107.016 | 107.063 |
| png16-pair | 249.453 | 126.625 | 245.063 | 123.531 |
| png40-plus16-pair | 263.313 | 140.516 | 244.922 | 126.453 |
| refused100-rgba | 4.516 | 4.500 | 0.156 | 0.094 |
| tiny-avif | 5.344 | 5.313 | 0.125 | 0.109 |
| cancel-replace | 264.797 | 142.219 | 244.860 | 124.031 |

Serialization substantially reduces the admitted-group peak. The 16 MP pair drops by 122.828 MiB cold (49.2%) and 121.531 MiB warm (49.6%). Single 40 MP PNG/JPEG peaks are effectively unchanged. Every heavy scenario’s cold and warm maximum remains above the 100 MiB starting incremental target.

The production mixed cold distribution spans 140.407–263.313 MiB and warm 122.563–244.922 MiB; candidate spans 128.250–140.516 MiB and 122.406–126.453 MiB. Production cancellation cold spans 264.782–264.797 MiB and warm 124.031–244.860 MiB; candidate spans 129.907–142.219 MiB and 122.438–124.031 MiB. The production low mixed/warm-cancellation samples observed one lease and the high samples two; exact arrival order was not recorded.

## Sample duration median (range), milliseconds

This duration includes fixture loading, source-header checks, actual decoding, explicit memory probes and sampler drain. It is not Finder first-visible latency.

| Scenario | Production cold | Serialized cold | Production warm | Serialized warm |
| --- | ---: | ---: | ---: | ---: |
| png40-rgba | 90.754 (90.645–93.818) | 93.233 (91.753–101.169) | 84.284 (83.407–85.601) | 88.162 (87.697–88.626) |
| jpeg40-rgb | 118.239 (117.159–120.377) | 123.358 (122.838–123.401) | 75.420 (74.134–80.192) | 75.286 (74.544–76.435) |
| png16-pair | 60.785 (60.546–68.099) | 106.875 (105.813–107.686) | 56.570 (55.591–57.278) | 110.958 (102.845–113.005) |
| png40-plus16-pair | 156.722 (148.081–196.207) | 195.635 (193.960–197.160) | 148.426 (138.276–191.872) | 194.459 (186.522–221.719) |
| refused100-rgba | 4.300 (4.229–4.420) | 4.457 (4.357–4.460) | 0.359 (0.254–0.453) | 0.290 (0.263–0.591) |
| tiny-avif | 95.293 (90.420–106.631) | 97.835 (91.782–103.358) | 4.707 (3.217–5.836) | 5.698 (3.336–8.365) |
| cancel-replace | 148.179 (146.846–149.161) | 200.536 (197.821–204.797) | 223.052 (220.398–269.688) | 282.149 (195.434–286.452) |

The pair median increases from 60.785 to 106.875 ms cold (75.8%) and 56.570 to 110.958 ms warm (96.1%). Mixed medians increase from 156.722 to 195.635 ms cold and 148.426 to 194.459 ms warm. Cancellation medians increase from 148.179 to 200.536 ms cold and 223.052 to 282.149 ms warm. These small distributions establish a throughput/overlap tradeoff for the measured workload, not release-wide latency acceptance.

## Absolute sampled peak / separate kernel lifetime peak (MiB)

Warm kernel lifetime values include the prior unmeasured warmup and earlier measured requests. They cannot be assigned to a single request.

| Scenario | Production cold | Serialized cold | Production warm | Serialized warm |
| --- | ---: | ---: | ---: | ---: |
| png40-rgba | 117.313 / 117.313 | 117.423 / 117.423 | 119.563 / 119.563 | 119.485 / 119.485 |
| jpeg40-rgb | 118.657 / 120.610 | 118.610 / 120.641 | 119.938 / 120.032 | 119.892 / 122.110 |
| png16-pair | 251.673 / 251.673 | 128.845 / 128.845 | 252.751 / 252.751 | 130.704 / 130.704 |
| png40-plus16-pair | 265.548 / 265.548 | 142.720 / 142.720 | 269.282 / 269.282 | 150.939 / 150.939 |
| refused100-rgba | 6.751 / 6.751 | 6.719 / 6.751 | 7.016 / 7.016 | 7.016 / 7.016 |
| tiny-avif | 7.563 / 7.563 | 7.532 / 7.532 | 6.360 / 6.360 | 6.360 / 6.360 |
| cancel-replace | 267.017 / 267.017 | 144.423 / 144.423 | 269.658 / 269.658 | 147.314 / 147.314 |

JPEG candidate sampled maxima are nearly unchanged, while the warm kernel lifetime maximum rises from 120.032 to 122.110 MiB. Both ledgers are retained rather than treating a sampled peak as the complete process peak.

## Held CGImage references / immediate post-drop maxima (MiB)

Each cell shows maximum held-reference footprint followed by immediate post-drop footprint across all eight samples. These are actual task-ledger readings, not bitmap byte estimates.

| Scenario | Production | Serialized |
| --- | ---: | ---: |
| png40-rgba | 20.345 / 20.282 | 20.266 / 20.204 |
| jpeg40-rgb | 14.516 / 14.454 | 14.516 / 14.454 |
| png16-pair | 8.438 / 8.329 | 8.548 / 8.438 |
| png40-plus16-pair | 24.954 / 24.782 | 28.782 / 28.626 |
| refused100-rgba | 7.016 / 7.016 | 7.016 / 7.016 |
| tiny-avif | 7.563 / 7.548 | 7.532 / 7.516 |
| cancel-replace | 25.329 / 25.157 | 25.157 / 25.001 |

Dropped references do not establish allocator/framework release. These samples hold decoded CGImage references only; actual AppKit drawing and NativeImagePagesView caching were not exercised. Do not infer physical cache residency from logical bitmap storage or subtract a drawing destination’s storage from a physical ledger.

## Evidence retained and scope

Raw reports/logs: `production-058335a.{json,log}` and `serialized-8mp-058335a.{json,log}`. Build/policy logs: `build-058335a.log`, `policy-058335a.log`. Exact metric distributions: `comparison-058335a.json`. Ignored worker/runner inputs were unchanged during build and measurement; no compiler repair was needed.

The environment remains Apple M5 Pro / Mac17,8 / arm64 / 48 GiB RAM, macOS 27.2 build 26B5091g, Xcode 27.0 build 27A266a, Swift 6.4, SDK 27.0, with a macOS 15 deployment target. Runtime on macOS 15, Finder first paint/routing, WindowServer/GPU/shared service totals, child/helper process or combined CAD memory remain outside this standalone workload. Actual held/drawn cache measurement remains separate. No production policy was selected, and 4 MP variants remain unselected.
