# Q154 serialized 8 MP admission experiment (ignored; uncompiled)

This is independent of the immutable `36ed46c` subsample experiment. Both modes call the unchanged production `ImagePageDecoder` and private native ImageIO implementation, with normal production 8 MP request sizes and the unchanged 40 MP source cap. No subsample option is injected. `production` uses the actual `.processWide` admission instance; `serialized-8mp` uses one retained `ImageDecodeAdmission(maximumSmallConcurrent: 1)` for the worker's warmup, measured samples and replacements. Cancellation uses a retained instance of the same production gate at the selected capacity with a causal acquisition observer. The observer is armed only between drained requests.

The two selectable modes are `production` and `serialized-8mp`. The 4 MP drafts remain separate and cannot be selected here. Serializing the existing native work preserves decoded dimensions/detail but reduces overlap/throughput. It does not fix the measured single-image footprint, so no 100 MiB target closure is assumed.

Each sample uses a new bounded 2 ms physical-footprint sampler, drained before the next sample. Reports preserve independent process kernel lifetime peaks, actual baseline/held/reference-drop probes, source bytes/dimensions, request sizes, decoded geometry/depth/stride/storage, and causal cancellation limitations. A retired task can be cancelled after admission without proving that C has begun or that native work was interrupted.

Both the worker and Python validator enforce actual sampled occupancy, rather than accepting only a configured limit:

- serialized heavy/small-pair/mixed/cancellation samples must observe exactly one active lease;
- the production 16 MP pair must observe exactly two active leases, proving the control exercised its parallel capacity;
- production single 40 MP samples must observe one; mixed/cancellation may observe one or two because FIFO arrival varies;
- 100 MP refusal must observe zero;
- tiny AVIF may observe zero or one because a short native call can finish between 2 ms probes. These samples do not prove native concurrency.

A missed required occupancy is a diagnostic failure; it is not silently accepted, padded with synthetic native work, or relaxed after observing results. Worker errors include the expected range and observed maximum. Gates must have zero running/waiting work before the sample is reset. The request/output validator rejects a hidden 4 MP reduction.

One executable supports both modes. The runner fingerprints tracked production/test inputs and its ignored worker source, runner, build commands, selected environment and executable. Mode selection is absent from the build context so the paired `--skip-build` measurements must reuse the same executable identity. Verify equality of source state, executable/build hashes, environment and every fixture SHA-256, source inventory, request and output geometry/storage before comparison. Cold runs are three fresh processes; warm runs are fresh processes with one separate unmeasured warmup and five measured samples for all seven scenarios. Collect full distributions and duration tradeoffs, not only maxima.

Portable checks: `test_benchmark_serialized_images.py` has seven passing tests. Initial missing-validator RED and a separate path-resolution RED are retained; no Swift compiler or native measurement has run for this draft.

After the lead commits report/integration changes and grants a frozen compiler/measurement slot, use:

```sh
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer python3 .build/quality-work/q154-footprint/experiments/serialized8/benchmark_serialized_images.py --admission-mode production --build-only
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer Packages/PreviewCore/.build/performance-images/arm64-apple-macosx/release/ReleaseImageAdmissionExperiment --check-experiment-policy
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer python3 .build/quality-work/q154-footprint/experiments/serialized8/benchmark_serialized_images.py --admission-mode production --skip-build --output .build/quality-work/q154-footprint/experiments/serialized8/production-FROZEN.json
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer python3 .build/quality-work/q154-footprint/experiments/serialized8/benchmark_serialized_images.py --admission-mode serialized-8mp --skip-build --output .build/quality-work/q154-footprint/experiments/serialized8/serialized-8mp-FROZEN.json
```

Use the granted commit in place of `FROZEN`, retain distinct raw logs, and do not invoke any command before the slot is granted. An actual AppKit held/drawn cache comparison is a separate stage; decoder-only samples do not establish Finder, cache materialization, WindowServer/GPU, combined CAD/child process totals or macOS 15 runtime evidence. The target remains 100 MiB and the resident-cache policy remains unchanged.
