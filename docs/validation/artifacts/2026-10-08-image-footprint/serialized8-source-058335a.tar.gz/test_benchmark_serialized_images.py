#!/usr/bin/env python3
"""Portable report-policy checks only; this never launches a Swift compiler."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[5] / 'script'))
import benchmark_serialized_images as admission
from test_benchmark_release_images import report


def value(scenario='png16-pair', mode='serialized-8mp', phase='cold', count=1):
    result = report(scenario, phase, count)
    result.update(admissionExperimentMode=mode, configuredSmallNativeLimit=1 if mode == 'serialized-8mp' else 2,
                  nativeDecodeMode='production')
    for sample in result['samples']:
        sample['admissionDrained'] = True
        sample['maximumActiveLeases'] = 0 if scenario == 'refused100-rgba' else (2 if mode == 'production' and scenario == 'png16-pair' else 1)
    return result


class AdmissionReportTests(unittest.TestCase):
    def test_runner_root_and_experiment_paths_resolve_from_ignored_location(self):
        self.assertEqual(admission.ROOT, Path(__file__).resolve().parents[5])
        self.assertEqual(admission.EXPERIMENT, Path(__file__).resolve().parent)

    def validate(self, r, scenario, mode, phase='cold', count=1):
        admission.validate_report(r, scenario, phase, count)
        admission.validate_admission_experiment(r, mode)

    def invalid(self, r, scenario='png16-pair', mode='serialized-8mp'):
        with self.assertRaises(ValueError): self.validate(r, scenario, mode)

    def test_complete_required_scenarios_cold_and_warm_in_both_modes(self):
        for mode in ('production', 'serialized-8mp'):
            for scenario in admission.SCENARIOS:
                for phase, count in [('cold', 1), ('warm', 5)]:
                    self.validate(value(scenario, mode, phase, count), scenario, mode, phase, count)

    def test_serialized_requires_observed_one_active_and_rejects_two(self):
        for scenario in ('png40-rgba', 'jpeg40-rgb', 'png16-pair', 'png40-plus16-pair', 'cancel-replace'):
            for invalid in (None, 0, 2, True):
                r=value(scenario);r['samples'][0]['maximumActiveLeases']=invalid
                self.invalid(r,scenario)

    def test_pair_control_must_observe_two_active_leases(self):
        for invalid in (0,1):
            r=value(mode='production');r['samples'][0]['maximumActiveLeases']=invalid
            self.invalid(r,mode='production')

    def test_tiny_call_may_miss_sampling_but_never_exceed_cap(self):
        for mode in ('production','serialized-8mp'):
            r=value('tiny-avif',mode);r['samples'][0]['maximumActiveLeases']=0
            self.validate(r,'tiny-avif',mode)
            r['samples'][0]['maximumActiveLeases']=2
            self.invalid(r,'tiny-avif',mode)

    def test_mode_native_path_limit_and_quiescence_must_match(self):
        for key, invalid in [('admissionExperimentMode','4mp-one-native'),('configuredSmallNativeLimit',2),
                             ('configuredSmallNativeLimit',True),('nativeDecodeMode','safe-subsample-2')]:
            r=value();r[key]=invalid;self.invalid(r)
        for invalid in ('missing',False,None,1):
            r=value()
            if invalid == 'missing': del r['samples'][0]['admissionDrained']
            else: r['samples'][0]['admissionDrained']=invalid
            self.invalid(r)

    def test_serialization_preserves_requests_and_bitmap_output(self):
        r=value();r['samples'][0]['requestedDecodeSides']=[2000,2000];self.invalid(r)
        r=value();r['samples'][0]['decodedBitmaps'][0]['width']=2000;self.invalid(r)


if __name__ == '__main__': unittest.main()
