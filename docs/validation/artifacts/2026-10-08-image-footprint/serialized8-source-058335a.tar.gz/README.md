# Serialized 8 MP experiment source archive

These worker and runner bytes were built and measured at clean 058335a08bff228ee7870a4f1b61f002d62523ba, without compiler repairs. The separate policy check and both complete three-cold/five-warm seven-scenario reports passed. Both modes use the unchanged production native decoder and preserve output geometry; the serial candidate changes only one retained admission gate's capacity.

DESIGN.md preserves the original preparation notes, including their then-uncompiled status. It is historical; the measurement result is the status above, not that preparation label. Raw reports/logs and the result amendment are retained separately, outside this source-only archive. No production optimization was selected, the 100 MiB target remains unmet, and actual held/drawn cache measurement remains separate.

Restore these files to .build/quality-work/q154-footprint/experiments/serialized8 inside a checkout of the measured revision. The manifest identifies exact tracked dependencies and measured source/build/executable fingerprints. Build or measurement requires an explicitly granted frozen compiler slot. No executable, build product, fixture, private input or raw report is included. Archive entries and gzip metadata are normalized deterministically.
